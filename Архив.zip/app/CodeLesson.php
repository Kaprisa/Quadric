<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CodeLesson extends Model
{
    //
}
