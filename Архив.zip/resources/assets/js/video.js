export default ((video) => {
    var supportsVideo = !!document.createElement('video').canPlayType;

    if (supportsVideo) {
        // Obtain handles to main elements

        //var video = document.getElementById('video');
        console.log(videoContainer)

    }
})()
