<template>
    <div>
        <router-view/>
    </div>
</template>

<script>
    /*import { mapActions } from 'vuex'*/
    export default {
        /*methods: {
            ...mapActions([
                'getTables'
            ]),
        },
        mounted() {
            this.getTables()
        },*/
    }
</script>

<style scoped>

</style>